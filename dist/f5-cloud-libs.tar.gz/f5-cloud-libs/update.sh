#!/bin/bash
#BIGIPS="10.145.69.74 10.145.69.76 10.145.69.47"
BIGIPS="10.145.69.74"
for bigip in ${BIGIPS}; do
    ping -c 1 $bigip
    if [[ $? -eq 0 ]]; then
        scp lib/bigIpCluster.js root@$bigip:/var/config/rest/iapps/f5-declarative-onboarding/nodejs/node_modules/@f5devcentral/f5-cloud-libs/lib/bigIpCluster.js
        ssh root@$bigip "bigstart restart restnoded"
    fi
done
