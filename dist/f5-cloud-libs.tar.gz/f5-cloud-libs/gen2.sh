#!/bin/bash

# This script generates the USAGE.md file

USAGE_FILE=GJD-USAGE.md

writeHelp () {
    IFS=''
    echo "" >> $USAGE_FILE
    node "$1" --help | while read LINE; do
        if [[ -z $LINE ]]; then
            LINE="  "
        fi
        echo "  ""$LINE" >> $USAGE_FILE
        if [[ $LINE == "Options:" ]]; then
          echo "" >> $USAGE_FILE
        fi
    done
}

# onboard
cat > $USAGE_FILE << EOL
# Usage

## onboard.js

Does initial configuration and provisioning of a BIG-IP.
EOL

writeHelp scripts/onboard.js

# cluster
